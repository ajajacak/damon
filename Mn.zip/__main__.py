import base64, zipfile, binascii, hashlib
SALT = binascii.unhexlify('3a95b20fc42e8f19efb7ed3d4645fe5efa913f0f56c34a771b51863d4ed3efec')
def gen_key_from_salt(salt, label, length):
    digest = hashlib.sha512(salt + label.encode()).digest()
    out = []
    while len(out) < length:
        digest = hashlib.sha512(digest).digest()
        out.extend(digest)
    return list(out[:length])
def mutate_key(key, salt):
    return [(b ^ salt[i % len(salt)]) for i, b in enumerate(key)]
RAW_KEY1 = gen_key_from_salt(SALT, "KEY_A", 40)
RAW_KEY2 = gen_key_from_salt(SALT, "KEY_B", 50)
KEY1 = mutate_key(RAW_KEY1, SALT)
KEY2 = mutate_key(RAW_KEY2, SALT)
with zipfile.ZipFile(".DAMON", "r") as z:
    encrypted_lines = z.read("DAMON").decode().splitlines()
out = []
for ln, encrypted in enumerate(encrypted_lines):
    intermediate = base64.b64decode(encrypted).decode()
    intermediate = intermediate.replace("DAMON::","").replace("::DAMON","")
    parts = intermediate.split("::")
    data = parts[0]
    dynamic_shift = ln % 255
    decrypted = ''.join(
        chr(ord(c) ^ KEY2[(i * 3 + dynamic_shift) % len(KEY2)])
        for i, c in enumerate(data)
    )
    decrypted = ''.join(
        chr(ord(c) ^ KEY1[(i + dynamic_shift) % len(KEY1)])
        for i, c in enumerate(decrypted)
    )
    out.append(decrypted)
exec("\n".join(out))
